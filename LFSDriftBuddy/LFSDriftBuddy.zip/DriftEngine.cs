using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;

namespace LFSDriftBuddy
{
    /// <summary>
    /// Calculates drift angle from CompCar data and awards points
    /// like Forza Horizon — rewards speed, angle, and sustained drifts.
    /// 
    /// InSim Direction/Heading: word, 0 = world Y axis, 32768 = 180 degrees.
    /// Drift angle = angular difference between motion direction and car heading.
    /// </summary>
    public class DriftEngine
    {
        // ── Drift scoring ───────────────────────────────────────
        private const double MIN_SPEED_KMH = 20.0;
        private const double MIN_DRIFT_ANGLE_DEG = 20.0;
        private const double MAX_DRIFT_ANGLE_DEG = 75.0;
        private const double COMBO_TIMEOUT_SEC = 2.5;
        private const double POINTS_PER_SECOND = 100.0;

        // ── Fast drive scoring ──────────────────────────────────
        private const double FAST_DRIVE_THRESHOLD = 110.0;
        private const double FAST_DRIVE_POINTS = 7.0;

        // ── Collision ──────────────────────────────────
        private double _lastSpeedKmh = 0;
        private double _lastHeadingDeg = 0;
        private DateTime _lastCollisionCheck = DateTime.UtcNow;
        private DateTime _lastCollisionTime = DateTime.MinValue;

        // ── State ───────────────────────────────────────────────
        public bool IsDrifting { get; private set; }
        public bool IsSpeeding { get; private set; }
        public double DriftAngleDeg { get; private set; }
        public bool DriftSideRight { get; private set; }
        public long CurrentRunPoints { get; private set; }
        public long TotalScore { get; private set; }
        public int ComboMultiplier { get; private set; } = 0;
        public double SpeedKmh { get; private set; }
        public string LastAwardedText { get; private set; } = "";

        // ── Driver ──────────────────────────────────────────────
        public string CurrentDriver { get; private set; } = "default_driver";

        private readonly string _statsFile = Path.Combine(
            AppDomain.CurrentDomain.BaseDirectory,
            "driver_stats.json");

        private Dictionary<string, long> _driverScores = new();

        private DateTime _driftStartTime;
        private DateTime _lastUpdateTime = DateTime.UtcNow;
        private DateTime _lastDriftTime = DateTime.MinValue;
        private double _dtSec = 0;
        private bool _previouslyDrifting = false;
        private bool _previouslyDriftSideRight = true;


        // ── Events ──────────────────────────────────────────────
        public event Action<long, int, string, string, string>? DriftScored;
        public event Action? DriftStarted;
        public event Action<long>? DriftEnded;

        public DriftEngine()
        {
            LoadStats();
        }

        // ────────────────────────────────────────────────────────
        //  Driver handling
        // ────────────────────────────────────────────────────────
        public void SetDriver(string driverName)
        {
            if (string.IsNullOrWhiteSpace(driverName))
                driverName = "default_driver";

            CurrentDriver = driverName;

            if (!_driverScores.ContainsKey(CurrentDriver))
                _driverScores[CurrentDriver] = 0;

            TotalScore = _driverScores[CurrentDriver];
        }

        // ────────────────────────────────────────────────────────
        //  Update
        // ────────────────────────────────────────────────────────
        public void Update(InSim.CompCar car)
        {
            var now = DateTime.UtcNow;

            _dtSec = (now - _lastUpdateTime).TotalSeconds;
            if (_dtSec > 0.5)
                _dtSec = 0.5;

            _lastUpdateTime = now;

            SpeedKmh = car.SpeedKmh;

            double motionDeg = car.Direction / 65536.0 * 360.0;
            double headingDeg = car.Heading / 65536.0 * 360.0;

            double diff = headingDeg - motionDeg;

            while (diff > 180) diff -= 360;
            while (diff < -180) diff += 360;

            DriftSideRight = diff >= 0 ? true : false;
            DriftAngleDeg = Math.Abs(diff);

            bool speeding = SpeedKmh >= FAST_DRIVE_THRESHOLD;

            bool drifting = SpeedKmh >= MIN_SPEED_KMH
                         && DriftAngleDeg >= MIN_DRIFT_ANGLE_DEG
                         && DriftAngleDeg <= MAX_DRIFT_ANGLE_DEG;

            // ── FAST DRIVE SCORING ─────────────────────────────
            

            if (!speeding && !drifting && !_previouslyDrifting) 
            { 
                //CurrentRunPoints = 0;
                IsSpeeding = false;

                //IsDrifting = false;


                _driftStartTime = now;
                double gap = (now - _lastDriftTime).TotalSeconds;

                if (gap <= COMBO_TIMEOUT_SEC && _lastDriftTime != DateTime.MinValue)
                   { }
                else
                {
                    
                    ComboMultiplier = 0;
                    //if (!speeding) { CurrentRunPoints = 0; }
                }




                //if (!speeding && !drifting && !_previouslyDrifting) { ComboMultiplier = 0; }

                if (ComboMultiplier <= 1 && !_previouslyDrifting) 
                {
                    CurrentRunPoints = 0;
                }
                else
                {

                }






            }



            if (!drifting && speeding)
            {
                if (SpeedKmh >= FAST_DRIVE_THRESHOLD * 2.2)
                    ComboMultiplier = 5;
                else if (SpeedKmh >= FAST_DRIVE_THRESHOLD * 1.9 && SpeedKmh < FAST_DRIVE_THRESHOLD * 2.2)
                    ComboMultiplier = 4;
                else if (SpeedKmh >= FAST_DRIVE_THRESHOLD * 1.6 && SpeedKmh < FAST_DRIVE_THRESHOLD * 1.9)
                    ComboMultiplier = 3;
                else if (SpeedKmh >= FAST_DRIVE_THRESHOLD * 1.3 && SpeedKmh < FAST_DRIVE_THRESHOLD * 1.6)
                    ComboMultiplier = 2;
                else if (SpeedKmh >= FAST_DRIVE_THRESHOLD * 1.0 && SpeedKmh < FAST_DRIVE_THRESHOLD * 1.3)
                    ComboMultiplier = 1;
                else { 
                ComboMultiplier = 1; }

                long fastPts = (long)(FAST_DRIVE_POINTS * _dtSec * ComboMultiplier);



                CurrentRunPoints += (long)fastPts;
                TotalScore += fastPts;
                IsSpeeding = true;





                SaveCurrentDriver();

                DriftScored?.Invoke(
                    CurrentRunPoints,
                    ComboMultiplier,
                    GetLabel(DriftAngleDeg, SpeedKmh),
                    GetDriftValueINDR(DriftAngleDeg, DriftSideRight),
                    GetDriftValueINDL(DriftAngleDeg, DriftSideRight)
                );
                //DriftEnded?.Invoke(CurrentRunPoints);
                if (!drifting)
                {
                    DriftEnded?.Invoke(CurrentRunPoints);
                    if (ComboMultiplier > 1) { }
                    else
                    {

                        //CurrentRunPoints = 0;

                    }
                    if (!speeding)
                    {
                        IsSpeeding = false;
                        //CurrentRunPoints = 0;
                         
                        //LastAwardedText = FormatRunResult(CurrentRunPoints, ComboMultiplier);
                    }
                    
                }
            }



            if (!drifting && _previouslyDrifting)
            {
                _lastDriftTime = now;

            }

            if (drifting)
            {
                if (!_previouslyDrifting)
                {
                    //CurrentRunPoints = 0;
                    
                    //
                    //
                    IsDrifting = true;
                    _driftStartTime = now;
                    double gap = (now - _lastDriftTime).TotalSeconds;

                    if (gap <= COMBO_TIMEOUT_SEC && _lastDriftTime != DateTime.MinValue)
                    {
                        if (_previouslyDriftSideRight != DriftSideRight)
                        {
                            ComboMultiplier = Math.Min(ComboMultiplier + 1, 10);
                           
                        }
                        
                    }
                    else
                    {
                        
                        ComboMultiplier = 1;
                        if (!speeding) {
                            
                            CurrentRunPoints = 0; 
                        }
                    }
                    

                    DriftStarted?.Invoke();
                }
                _previouslyDriftSideRight = DriftSideRight;
                double angleScore = AngleScore(DriftAngleDeg);
                double speedScore = SpeedScore(SpeedKmh);

                double framePts = POINTS_PER_SECOND
                                * angleScore
                                * speedScore
                                * ComboMultiplier
                                * _dtSec;

                CurrentRunPoints += (long)framePts;
                TotalScore += (long)framePts;

                SaveCurrentDriver();


                



                DriftScored?.Invoke(
                    CurrentRunPoints,
                    ComboMultiplier,
                    GetLabel(DriftAngleDeg, SpeedKmh),
                    GetDriftValueINDR(DriftAngleDeg, DriftSideRight),
                    GetDriftValueINDL(DriftAngleDeg, DriftSideRight)
                );
            }
            else if (_previouslyDrifting)
            {
                IsDrifting = false;
                _lastDriftTime = now;

                //
                

                SaveCurrentDriver();
                

                
                
                if (!speeding) 
                {

                    if (ComboMultiplier >= 1) { }
                    else
                    {

                        

                    }

                    
                    //LastAwardedText = FormatRunResult(CurrentRunPoints, ComboMultiplier);
                    //_driftStartTime = now;
                    
                    DriftEnded?.Invoke(CurrentRunPoints);



                    IsSpeeding = false;


                }
                
            }


            if (!speeding && !drifting && _previouslyDrifting)
            {

                

                if (ComboMultiplier>1) { }
                else
                {
                    //LastAwardedText = FormatRunResult(CurrentRunPoints, ComboMultiplier);
                    //CurrentRunPoints = 0;

                }
                
               
            }

           
            _previouslyDrifting = drifting;
        }

        // ────────────────────────────────────────────────────────
        //  Persistence
        // ────────────────────────────────────────────────────────
        private void LoadStats()
        {
            try
            {
                if (!File.Exists(_statsFile))
                {
                    _driverScores = new Dictionary<string, long>();
                    return;
                }

                string json = File.ReadAllText(_statsFile);

                _driverScores = JsonSerializer.Deserialize<Dictionary<string, long>>(json)
                                ?? new Dictionary<string, long>();
            }
            catch
            {
                _driverScores = new Dictionary<string, long>();
            }
        }

        private void SaveCurrentDriver()
        {
            try
            {
                _driverScores[CurrentDriver] = TotalScore;

                string json = JsonSerializer.Serialize(
                    _driverScores,
                    new JsonSerializerOptions
                    {
                        WriteIndented = true
                    });

                File.WriteAllText(_statsFile, json);
            }
            catch
            {
            }
        }

        // ────────────────────────────────────────────────────────
        //  Helpers
        // ────────────────────────────────────────────────────────
        private static double AngleScore(double angle)
        {
            double norm = angle / 40.0;

            if (norm > 1.0)
                norm = 1.0 + (angle - 40.0) / 35.0 * -0.3;
            norm = norm * 0.4;
            return Math.Max(0.5, Math.Min(2.5, norm));
        }

        private static double SpeedScore(double kmh)
        {
            double norm = kmh / (FAST_DRIVE_THRESHOLD - 40);
            return Math.Max(0.5, Math.Min(2.5, norm));
        }

        private static string GetDriftValueINDR(double angle, bool side)
        {
            if (side == true)
            {
                if (angle > 55) return " >>>>";
                if (angle > 45) return " >>>";
                if (angle > 30) return " >>";
                if (angle > 15) return " >";
            }
            else
            {
                if (angle > 55) return "     ";
                if (angle > 45) return "    ";
                if (angle > 30) return "   ";
                if (angle > 15) return "  ";
            }

            return "";
        }
        private static string GetDriftValueINDL(double angle, bool side)
        {
            if (side == false)
            {
                if (angle > 55) return "<<<< ";
                if (angle > 40) return "<<< ";
                if (angle > 25) return "<< ";
                if (angle > 10) return "< ";
            }
            else
            {
                if (angle > 55) return "     ";
                if (angle > 45) return "    ";
                if (angle > 30) return "   ";
                if (angle > 15) return "  ";
            }

            return "";
        }
        private static string GetLabel(double angle, double speed)
        {
            if (speed >= FAST_DRIVE_THRESHOLD && angle < 8 && speed < FAST_DRIVE_THRESHOLD * 1.5)
                return "SZYBKA JAZDA";
            if (speed >= FAST_DRIVE_THRESHOLD * 1.5 && angle < 8 && speed < FAST_DRIVE_THRESHOLD * 2.0)
                return "POJEBANA JAZDA!";
            if (speed >= FAST_DRIVE_THRESHOLD * 2.0 && angle < 8)
                return "POKURWIONA JAZDA!";
            if (angle > 55) return "DOSPERMIONY DRIFT";
            if (angle > 45) return "DOJEBANY DRIFT";
            if (angle > 30) return "DOBRY DRIFT";
            if (angle < 30 && angle > 15) return "DRIFT";
            if (speed > 120 && angle > 20) return "SZYBKI DRIFT";

            return "DRIFT";
        }

        private static string FormatRunResult(long pts, int combo)
        {
            if (pts >= 5000) return $"SPERMASTYCZNIE! {pts:N0} pts";
            if (pts >= 2500) return $"ALE DOJEBAŁEŚ! {pts:N0} pts";
            if (pts >= 1000) return $"NAJS! {pts:N0} pts";
            if (pts >= 500) return $"NO NIEŹLE! {pts:N0} pts";

            return $"{pts:N0} pts";
        }

        public void ResetTotal()
        {
            TotalScore = 0;
            ComboMultiplier = 1;
            CurrentRunPoints = 0;
            IsDrifting = false;
            IsSpeeding = false;
            _previouslyDrifting = false;
            _lastDriftTime = DateTime.MinValue;

            SaveCurrentDriver();
        }



    }
}
