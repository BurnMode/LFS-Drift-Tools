using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using LFSDriftBuddy.InSim;

namespace LFSDriftBuddy
{
    public partial class MainForm : Form
    {
        // ── InSim + Drift ─────────────────────────────────────
        private InSimConnection _insim;
        private DriftEngine     _drift = new DriftEngine();
        private IndicatorManager _indicators = new IndicatorManager();
        private byte _playerPLID = 0;  // ← NOWE POLE
        private byte _lastKnownPlayerPLID = 0;  // fallback, gdy IS_STA jeszcze nie doszedł

        // ── Current data ──────────────────────────────────────
        private double _speedKmh       = 0;
        private double _driftAngle     = 0;
        private long   _runPoints      = 0;
        private long   _totalScore     = 0;
        private int    _combo          = 1;
        private bool   _isDrifting     = false;
        private bool   _isSpeeding     = false;
        private string _driftLabel     = "";
        private string _indicatorLabelR = "";
        private string _indicatorLabelL = "";
        private string _lastAward      = "";

        private Label _rpmLabel = null!;
        private Label _revCutLabel = null!;
        private ProgressBar _rpmBar = null!;

        // ── LFS button IDs ────────────────────────────────────
        private const byte BTN_SCORE    = 1;   // total score top-center
        private const byte BTN_RUN      = 2;   // current run points
        private const byte BTN_COMBO    = 3;   // combo multiplier
        private const byte BTN_LABEL    = 4;   // drift label text
        private const byte BTN_AWARD    = 5;   // flash on drift end
        private const byte BTN_RIGHTIND    = 6;   // flash on drift end
        private const byte BTN_LEFTIND    = 7;   // flash on drift end

        // ── Timer for award flash ─────────────────────────────
        private System.Windows.Forms.Timer _awardTimer;
        private int _awardTick = 0;

        // ── UI Controls ───────────────────────────────────────
        private SpeedometerControl _speedometer;
        private Label  _speedLabel, _speedUnitLabel;
        private Label  _angleLabel, _angleValueLabel;
        private Label  _comboLabel, _comboValueLabel;
        private Label  _scoreLabel, _scoreValueLabel;
        private Label  _runLabel,   _runValueLabel;
        private Label  _statusLabel;
        private TextBox _hostBox, _adminBox;
        private NumericUpDown _portBox;
        private Button _connectBtn, _disconnectBtn, _resetBtn;
        private Label  _connectionStateLabel;
        private CheckBox _showHudCheck;

        // ── UI Colors ─────────────────────────────────────────

        private string InSimColor1 = "^7";
        private string InSimColor2 = "^6";
        private string InSimColor3 = "^3";
        private string InSimColor4 = "^5";

        private Button _colorBtn1;
        private Button _colorBtn2;
        private Button _colorBtn3;
        private Button _colorBtn4;

        // ── Kierunkowskazy ────────────────────────────────────
        private Label _indicatorStatusLabel;
        private Button _bindLeftBtn, _bindRightBtn, _bindHazardBtn;
        private CheckBox _autoReturnCheck;
        private Label _tireStatusLabel;
        private Button _tirePatchBtn;
        private NumericUpDown _steeringThresholdBox;
        private Label _indicatorDisplayLabel;

        public MainForm()
        {
            _insim = new InSimConnection();

            _insim.CarDataReceived += OnCarData;
            _insim.StatusChanged   += OnStatus;
            _insim.Connected       += OnConnected;
            _insim.Disconnected    += OnDisconnected;
            _insim.RaceStateChanged += (s, inRace) => BeginInvoke((Action)(() =>
            {
                if (inRace)
                    InitInGameHUD();      // pojawiają się przyciski
                else
                    _insim.DeleteAllButtons(); // znikają w menu/powtórce
            }));
            _drift.SetDriver(Environment.UserName);
            _revLimiter.DataReceived += OnRevData;
            _revLimiter.CutStarted += () => BeginInvoke((Action)(() => _revCutLabel.Text = "⚡ CUT"));
            _revLimiter.CutEnded += () => BeginInvoke((Action)(() => _revCutLabel.Text = ""));
            _revLimiter.Error += msg => BeginInvoke((Action)(() => _statusLabel.Text = msg));

            // ── Tire Temperature Limiter ──────────────────────────────
            _tireTemperatureLimiter.Log += msg => BeginInvoke((Action)(() => _statusLabel.Text = msg));
            _tireTemperatureLimiter.PatchStatusChanged += status =>
                BeginInvoke((Action)(() => UpdateTireLimiterUI(status)));


            _drift.DriftScored  += OnDriftScored;
            _drift.DriftStarted += OnDriftStarted;
            _drift.DriftEnded   += OnDriftEnded;

            _indicators.StateChanged += OnIndicatorStateChanged;

            _awardTimer = new System.Windows.Forms.Timer { Interval = 120 };
            _awardTimer.Tick += AwardTimer_Tick;

            InitializeComponent();
            BuildUI();
        }
        private RevLimiter _revLimiter = new RevLimiter();
        private TireTemperatureLimiter _tireTemperatureLimiter = new TireTemperatureLimiter();
        private void OnRevData(OutGaugeData data)
        {
            BeginInvoke((Action)(() =>
            {
                _rpmLabel.Text = ((int)data.RPM).ToString("N0");
                _rpmBar.Value = (int)Math.Min(data.RPM, _rpmBar.Maximum);
                // Podświetl czerwono gdy blisko limitu
                _rpmLabel.ForeColor = data.RPM >= _revLimiter.RpmLimit * 0.95
                    ? Color.FromArgb(255, 60, 60)
                    : Color.FromArgb(80, 220, 120);
            }));
        }
        // ─────────────────────────────────────────────────────
        //  UI
        // ─────────────────────────────────────────────────────
        private void BuildUI()
        {
            Text            = "LFS DRIFT BUDDY";
            Size            = new Size(950, 570);
            MinimumSize     = new Size(950, 570);
            MaximumSize     = new Size(950, 570);
            StartPosition   = FormStartPosition.CenterScreen;
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox     = false;
            BackColor       = Color.FromArgb(13, 13, 20);
            Font            = new Font("Segoe UI", 9f);

            // ── Header ───────────────────────────────────────
            var header = MakePanel(0, 0, 950, 76, Color.FromArgb(18, 18, 28));
            Controls.Add(header);
            MakePanel(0, 0, 950, 3, Color.FromArgb(220, 40, 40), header);  // red top accent

            MakeLabel(header, "LFS DRIFT BUDDY", 18, 10, 300, 34,
                      Color.White, new Font("Segoe UI", 20f, FontStyle.Bold));
            MakeLabel(header, "InSim Telemetry + Drift Scoring", 20, 46, 200, 18,
                      Color.FromArgb(140, 140, 170));

            _connectBtn = MakeButton(header, "CONNECT", 435, 7, 120, 32, Color.FromArgb(200, 35, 35));
            _disconnectBtn = MakeButton(header, "DISCONNECT", 435, 43, 120, 32, Color.FromArgb(55, 55, 75));
            _disconnectBtn.Enabled = false;
            _connectBtn.Click += (s, e) => _insim.Connect(_hostBox.Text.Trim(), (int)_portBox.Value, _adminBox.Text);
            _disconnectBtn.Click += (s, e) => { _insim.DeleteAllButtons(); System.Threading.Thread.Sleep(80); _insim.Disconnect(); };

            _connectionStateLabel = MakeLabel(header, "⬤  Disconnected", 559, 58, 400, 16, Color.FromArgb(130, 130, 165), new Font("Segoe UI", 8f));

            MakeLabel(header, "Host:", 560, 7, 45, 22, Color.FromArgb(130, 130, 165));
            _hostBox = MakeTextBox(header, "127.0.0.1", 562, 32, 100, 24);

            MakeLabel(header, "Port:", 663, 7, 38, 22, Color.FromArgb(130, 130, 165));
            _portBox = new NumericUpDown
            {
                Location = new Point(666, 32),
                Size = new Size(78, 24),
                Minimum = 1,
                Maximum = 65535,
                Value = 29999,
                ForeColor = Color.White,
                BackColor = Color.FromArgb(32, 32, 50),
                BorderStyle = BorderStyle.FixedSingle
            };
            header.Controls.Add(_portBox);

            MakeLabel(header, "Admin password:", 745, 7, 100, 22, Color.FromArgb(130, 130, 165));
            _adminBox = MakeTextBox(header, "", 748, 32, 140, 24);

            // ── Speedometer ───────────────────────────────────
            _speedometer = new SpeedometerControl
            {
                Location = new Point(70, 86),
                Size     = new Size(300, 150),
                BackColor = Color.Black
            };
            Controls.Add(_speedometer);

            // ── Speed + Angle readout ─────────────────────────
            var readout = MakePanel(10, 240, 420, 60, Color.FromArgb(18, 18, 28));
            Controls.Add(readout);
            readout.Paint += BorderPaint(Color.FromArgb(50, 50, 70));

            _speedLabel     = MakeLabel(readout, "0",     5,  4, 70, 50, Color.FromArgb(220,40,40), new Font("Segoe UI", 30f, FontStyle.Bold), ContentAlignment.MiddleRight);
            _speedUnitLabel = MakeLabel(readout, "km/h", 90,  28,  50, 20, Color.FromArgb(120,120,160));
            MakeLabel(readout, "SPEED", 8, 4, 130, 14, Color.FromArgb(90,90,120), new Font("Segoe UI", 7f, FontStyle.Bold), ContentAlignment.TopRight);

            _angleValueLabel = MakeLabel(readout, "0°",  200, 4, 110, 50, Color.FromArgb(60,180,255), new Font("Segoe UI", 30f, FontStyle.Bold), ContentAlignment.MiddleRight);
            MakeLabel(readout, "DRIFT ANGLE", 250, 4, 130, 14, Color.FromArgb(90,90,120), new Font("Segoe UI", 7f, FontStyle.Bold), ContentAlignment.TopRight);
            MakeLabel(readout, "deg", 335, 28, 50, 20, Color.FromArgb(120,120,160));

            // ── Drift scoring panel ───────────────────────────
            var scorePanel = MakePanel(10, 305, 420, 100, Color.FromArgb(18, 18, 28));
            Controls.Add(scorePanel);
            scorePanel.Paint += BorderPaint(Color.FromArgb(50, 50, 70));
            scorePanel.Paint += (s, e) =>
            {
                using var br = new SolidBrush(Color.FromArgb(25, 25, 40));
                e.Graphics.FillRectangle(br, 1, 1, scorePanel.Width - 2, 22);
                using var fb = new SolidBrush(Color.FromArgb(160, 160, 200));
                using var f  = new Font("Segoe UI", 8f, FontStyle.Bold);
                e.Graphics.DrawString("  DRIFT SCORE", f, fb, new Point(4, 4));
            };

            MakeLabel(scorePanel, "TOTAL SCORE",   12, 28, 110, 14, Color.FromArgb(100,100,140), new Font("Segoe UI", 7.5f, FontStyle.Bold));
            _scoreValueLabel = MakeLabel(scorePanel, "0", 12, 42, 140, 44, Color.FromArgb(255,200,50), new Font("Segoe UI", 20f, FontStyle.Bold));

            MakeLabel(scorePanel, "RUN SCORE",  180, 28, 100, 14, Color.FromArgb(100,100,140), new Font("Segoe UI", 7.5f, FontStyle.Bold));
            _runValueLabel = MakeLabel(scorePanel, "0",  180, 42, 140, 44, Color.FromArgb(80,220,120), new Font("Segoe UI", 20f, FontStyle.Bold));

            MakeLabel(scorePanel, "COMBO",         340, 28, 100, 14, Color.FromArgb(100,100,140), new Font("Segoe UI", 7.5f, FontStyle.Bold));
            _comboValueLabel = MakeLabel(scorePanel, "x1", 340, 42, 100, 44, Color.FromArgb(255,120,40), new Font("Segoe UI", 24f, FontStyle.Bold));

            // ── Connection panel ─────────────────────────────
            var conn = MakePanel(435, 80, 495, 155, Color.FromArgb(18, 18, 28));
            Controls.Add(conn);
            conn.Paint += BorderPaint(Color.FromArgb(50, 50, 70));
            conn.Paint += (s, e) =>
            {
                using var br = new SolidBrush(Color.FromArgb(25, 25, 40));
                e.Graphics.FillRectangle(br, 1, 1, conn.Width - 2, 22);
                using var fb = new SolidBrush(Color.FromArgb(160, 160, 200));
                using var f  = new Font("Segoe UI", 8f, FontStyle.Bold);
                e.Graphics.DrawString("  HUD OPTIONS", f, fb, new Point(4, 4));
            };


            _colorBtn1 = MakeButton(conn, "", 10, 40, 40, 40, Color.White);
            _colorBtn2 = MakeButton(conn, "", 60, 40, 40, 40, Color.Cyan);
            _colorBtn3 = MakeButton(conn, "", 110, 40, 40, 40, Color.Yellow);
            _colorBtn4 = MakeButton(conn, "", 160, 40, 40, 40, Color.Magenta);



            _colorBtn1.Click += (s, e) => OpenInSimPalette(_colorBtn1, c => InSimColor1 = c);
            _colorBtn2.Click += (s, e) => OpenInSimPalette(_colorBtn2, c => InSimColor2 = c);
            _colorBtn3.Click += (s, e) => OpenInSimPalette(_colorBtn3, c => InSimColor3 = c);
            _colorBtn4.Click += (s, e) => OpenInSimPalette(_colorBtn4, c => InSimColor4 = c);


            _resetBtn      = MakeButton(conn, "RESET SCORE", 328, 115, 160, 32, Color.FromArgb(40,80,60));
            
            _resetBtn.Enabled      = false;

            
            _resetBtn.Click      += (s, e) => { _drift.ResetTotal(); UpdateScoreLabels(); };

            

            // ── HUD options ───────────────────────────────────
            var hud = MakePanel(435, 240, 495, 60, Color.FromArgb(18, 18, 28));
            Controls.Add(hud);
            hud.Paint += BorderPaint(Color.FromArgb(50, 50, 70));
            hud.Paint += (s, e) =>
            {
                using var br = new SolidBrush(Color.FromArgb(25, 25, 40));
                e.Graphics.FillRectangle(br, 1, 1, hud.Width - 2, 22);
                using var fb = new SolidBrush(Color.FromArgb(160, 160, 200));
                using var f  = new Font("Segoe UI", 8f, FontStyle.Bold);
                e.Graphics.DrawString("  DRIFT BUDDY HUD W GRZE", f, fb, new Point(4, 4));
            };
            _showHudCheck = new CheckBox
            {
                Text = "Show ingame HUD (IS_BTN)",
                Location = new Point(10, 30), Size = new Size(380, 20),
                ForeColor = Color.FromArgb(200, 200, 220), BackColor = Color.Transparent,
                Checked = true
            };
            hud.Controls.Add(_showHudCheck);

            // ── Status bar ────────────────────────────────────
            Controls.Add(MakePanel(10, 407, 420, 1, Color.FromArgb(40,40,60)));
            var statusBar = MakePanel(10, 408, 420, 28, Color.FromArgb(10,10,16));
            Controls.Add(statusBar);
            _statusLabel = MakeLabel(statusBar, "Type /insim 29999 w LFS, and click CONNECT.", 0, 6, 520, 18, Color.FromArgb(110,110,150), new Font("Segoe UI", 8f));



            var revPanel = MakePanel(435, 305, 495, 130, Color.FromArgb(18, 18, 28));
            Controls.Add(revPanel);
            revPanel.Paint += BorderPaint(Color.FromArgb(50, 50, 70));
            revPanel.Paint += (s, e) => {
                using var br = new SolidBrush(Color.FromArgb(25, 25, 40));
                e.Graphics.FillRectangle(br, 1, 1, revPanel.Width - 2, 22);
                using var fb = new SolidBrush(Color.FromArgb(160, 160, 200));
                using var f = new Font("Segoe UI", 8f, FontStyle.Bold);
                e.Graphics.DrawString("  REV LIMITER (OutGauge)", f, fb, new Point(4, 4));
            };

            MakeLabel(revPanel, "RPM:", 10, 32, 45, 22, Color.FromArgb(130, 130, 165));
            _rpmLabel = MakeLabel(revPanel, "0", 58, 28, 120, 30,
                Color.FromArgb(80, 220, 120), new Font("Segoe UI", 18f, FontStyle.Bold));
            _revCutLabel = MakeLabel(revPanel, "", 165, 28, 80, 30,
                Color.FromArgb(255, 60, 60), new Font("Segoe UI", 14f, FontStyle.Bold));

            // RPM bar
            _rpmBar = new ProgressBar
            {
                Location = new Point(10, 62),
                Size = new Size(475, 12),
                Minimum = 0,
                Maximum = 12000,
                Value = 0,
                Style = ProgressBarStyle.Continuous
            };
            revPanel.Controls.Add(_rpmBar);

            // Ustawienia: próg RPM
            MakeLabel(revPanel, "RPM limit:", 10, 90, 70, 22, Color.FromArgb(130, 130, 165));
            var rpmLimitBox = new NumericUpDown
            {
                Location = new Point(85, 90),
                Size = new Size(80, 24),
                Minimum = 1000,
                Maximum = 20000,
                Value = 7500,
                Increment = 100,
                ForeColor = Color.White,
                BackColor = Color.FromArgb(32, 32, 50),
                BorderStyle = BorderStyle.FixedSingle
            };
            rpmLimitBox.ValueChanged += (s, e) => _revLimiter.RpmLimit = (int)rpmLimitBox.Value;
            revPanel.Controls.Add(rpmLimitBox);

            MakeLabel(revPanel, "Cut time [ms]:", 175, 90, 100, 22, Color.FromArgb(130, 130, 165));
            var cutMsBox = new NumericUpDown
            {
                Location = new Point(280, 90),
                Size = new Size(80, 24),
                Minimum = 20,
                Maximum = 500,
                Value = 40,
                Increment = 10,
                ForeColor = Color.White,
                BackColor = Color.FromArgb(32, 32, 50),
                BorderStyle = BorderStyle.FixedSingle
            };
            cutMsBox.ValueChanged += (s, e) => _revLimiter.CutMs = (int)cutMsBox.Value;
            revPanel.Controls.Add(cutMsBox);

            var revEnableBtn = MakeButton(revPanel, "TURN OFF LIMMIER", 374, 88, 110, 28,
                Color.FromArgb(180, 35, 35));
            revEnableBtn.Click += (s, e) => {
                _revLimiter.Enabled = !_revLimiter.Enabled;
                revEnableBtn.Text = _revLimiter.Enabled ? "TURN OFF LIMMIER" : "TURN ON LIMMIER";
                revEnableBtn.BackColor = _revLimiter.Enabled
                    ? Color.FromArgb(180, 35, 35) : Color.FromArgb(40, 80, 60);
                if (!_revLimiter.IsRunning) _revLimiter.Start();
            };

            /*
            // ────────────────────────────────────────────────────────
            // Tire Temperature Limiter Section
            // ────────────────────────────────────────────────────────
            var tirePanel = MakePanel(100, 390, 450, 100, Color.FromArgb(22, 22, 35));
            tirePanel.Paint += BorderPaint(Color.FromArgb(60, 120, 180));

            _tireStatusLabel = MakeLabel(tirePanel, "❌ Not Patched", 10, 10, 280, 20,
                Color.FromArgb(150, 150, 150), new Font("Segoe UI", 9, FontStyle.Bold));

            _tirePatchBtn = MakeButton(tirePanel, "APPLY PATCH", 300, 10, 130, 25,
                Color.FromArgb(180, 60, 60));

            _tirePatchBtn.Click += (s, e) =>
            {
                try
                {
                    if (!_tireTemperatureLimiter.IsConnected)
                    {
                        _statusLabel.Text = "🔄 Connecting to LFS...";
                        if (!_tireTemperatureLimiter.Connect())
                        {
                            _statusLabel.Text = "❌ Failed to connect to LFS - check if it's running and you have admin rights";
                            return;
                        }
                    }

                    if (_tireTemperatureLimiter.IsPatched)
                    {
                        _tireTemperatureLimiter.Unpatch();
                    }
                    else
                    {
                        _tireTemperatureLimiter.Patch();
                    }
                }
                catch (Exception ex)
                {
                    _statusLabel.Text = $"❌ Error: {ex.Message}";
                }
            };

            MakeLabel(tirePanel, "🌡️ Tire Temperature Limiting (LFS 0.8C)",
                10, 40, 420, 15, Color.FromArgb(100, 200, 255),
                new Font("Segoe UI", 8, FontStyle.Bold));

            MakeLabel(tirePanel, "Wyłącza wzrost temperatury opon dla lepszego driftingu",
                10, 58, 420, 15, Color.FromArgb(100, 100, 100),
                new Font("Segoe UI", 8));

            */

            // ── Kierunkowskazy panel ──────────────────────────
            var indicPanel = MakePanel(10, 410, 920, 120, Color.FromArgb(18, 18, 28));
            Controls.Add(indicPanel);
            indicPanel.Paint += BorderPaint(Color.FromArgb(50, 50, 70));
            indicPanel.Paint += (s, e) =>
            {
                using var br = new SolidBrush(Color.FromArgb(25, 25, 40));
                e.Graphics.FillRectangle(br, 1, 1, indicPanel.Width - 2, 22);
                using var fb = new SolidBrush(Color.FromArgb(160, 160, 200));
                using var f = new Font("Segoe UI", 8f, FontStyle.Bold);
                e.Graphics.DrawString("  Turn signals", f, fb, new Point(4, 4));
            };

            // Wyświetlanie stanu kierunkowskazów
            _indicatorDisplayLabel = MakeLabel(indicPanel, "---", 10, 30, 150, 30,
                Color.FromArgb(100, 200, 255), new Font("Segoe UI", 14f, FontStyle.Bold));

            // Bindowanie klawiszy
            MakeLabel(indicPanel, "Key bind:", 175, 30, 120, 18, Color.FromArgb(130, 130, 165));
            _bindLeftBtn = MakeButton(indicPanel, "LEFT (7)", 175, 50, 75, 26, Color.FromArgb(60, 120, 180));
            _bindRightBtn = MakeButton(indicPanel, "RIGHT (8)", 255, 50, 75, 26, Color.FromArgb(60, 120, 180));
            _bindHazardBtn = MakeButton(indicPanel, "HAZARD (9)", 335, 50, 85, 26, Color.FromArgb(60, 120, 180));

            _bindLeftBtn.Click += (s, e) => BindKey("LEFT TURN SIGNAL", k => _indicators.LeftKeyCode = (int)k);
            _bindRightBtn.Click += (s, e) => BindKey("RIGHT TURN SIGNAL", k => _indicators.RightKeyCode = (int)k);
            _bindHazardBtn.Click += (s, e) => BindKey("HAZARD SIGNALS", k => _indicators.HazardKeyCode = (int)k);

            /*
            // Auto-return i ustawienia
            _autoReturnCheck = new CheckBox
            {
                Text = "Auto-wyłączanie po prostowaniu kierownicy",
                Location = new Point(435, 52),
                Size = new Size(300, 20),
                ForeColor = Color.FromArgb(200, 200, 220),
                BackColor = Color.Transparent,
                Checked = true
            };
            _autoReturnCheck.CheckedChanged += (s, e) => _indicators.AutoReturnEnabled = _autoReturnCheck.Checked;
            indicPanel.Controls.Add(_autoReturnCheck);

            MakeLabel(indicPanel, "Próg skrętu [°]:", 435, 75, 95, 18, Color.FromArgb(130, 130, 165));
            _steeringThresholdBox = new NumericUpDown
            {
                Location = new Point(535, 72),
                Size = new Size(60, 24),
                Minimum = 1,
                Maximum = 45,
                Value = 10,
                Increment = 1,
                ForeColor = Color.White,
                BackColor = Color.FromArgb(32, 32, 50),
                BorderStyle = BorderStyle.FixedSingle
            };
            _steeringThresholdBox.ValueChanged += (s, e) => _indicators.SteeringReturnThreshold = (double)_steeringThresholdBox.Value;
            indicPanel.Controls.Add(_steeringThresholdBox);
            */

            _indicatorStatusLabel = MakeLabel(indicPanel, "", 640, 30, 270, 80,
                Color.FromArgb(150, 200, 100), new Font("Segoe UI", 9f));


        }

        // Pomocna metoda do bindowania klawiszy
        private Keys _pendingKeyBind = Keys.None;
        private void BindKey(string keyName, Action<Keys> onKeyBound)
        {
            // Niestandardowa forma do bindowania z override ProcessCmdKey
            var dialog = new KeyBindingForm(keyName);

            if (dialog.ShowDialog(this) == DialogResult.OK)
            {
                Keys boundKey = dialog.BoundKey;
                if (boundKey != Keys.None && boundKey != Keys.Escape)
                {
                    onKeyBound(boundKey);
                    _statusLabel.Text = $"Klawisz '{keyName}' zmieniony na: {boundKey}";
                }
            }
        }

        // ────────────────────────────────────────────────────────
        // Niestandardowy dialog do bindowania klawiszy
        // ────────────────────────────────────────────────────────
        public class KeyBindingForm : Form
        {
            public Keys BoundKey { get; private set; } = Keys.None;
            private Label _instructionLabel;

            public KeyBindingForm(string keyName)
            {
                Text = "Bindowanie klawisza";
                Size = new Size(350, 150);
                StartPosition = FormStartPosition.CenterParent;
                FormBorderStyle = FormBorderStyle.FixedDialog;
                MaximizeBox = false;
                MinimizeBox = false;
                BackColor = Color.FromArgb(20, 20, 30);
                KeyPreview = true;  // ← WAŻNE! Pozwala formie przechwycić wszystkie klawisze

                _instructionLabel = new Label
                {
                    Text = $"Naciśnij klawisz dla: {keyName}\n\n(Naciśnij ESC aby anulować)",
                    Dock = DockStyle.Fill,
                    ForeColor = Color.White,
                    Font = new Font("Segoe UI", 11f),
                    TextAlign = ContentAlignment.MiddleCenter,
                    AutoSize = false
                };
                Controls.Add(_instructionLabel);
            }

            // Override ProcessCmdKey - przechwytuje wszystkie klawisze
            protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
            {
                if (msg.Msg == 0x0100)  // WM_KEYDOWN
                {
                    // Filtruj modyfikatory (Ctrl, Shift, Alt)
                    Keys baseKey = keyData & Keys.KeyCode;

                    if (baseKey == Keys.Escape)
                    {
                        DialogResult = DialogResult.Cancel;
                        Close();
                        return true;
                    }

                    // Zapisz bindowany klawisz
                    BoundKey = baseKey;
                    _instructionLabel.Text = $"Bindowano: {baseKey}\n\nKlikaj by wrócić...";
                    _instructionLabel.ForeColor = Color.FromArgb(100, 200, 100);

                    // Zamknij dialog
                    System.Threading.Thread.Sleep(300);  // Pokaż potwierdzenie
                    DialogResult = DialogResult.OK;
                    Close();
                    return true;
                }

                return base.ProcessCmdKey(ref msg, keyData);
            }
        }


        private string ToInSimColor(Color c)
        {
            if (c == Color.Black) return "^0";
            if (c == Color.Red) return "^1";
            if (c == Color.LimeGreen) return "^2";
            if (c == Color.Yellow) return "^3";
            if (c == Color.Blue) return "^4";
            if (c == Color.Magenta) return "^5";
            if (c == Color.Cyan) return "^6";
            if (c == Color.White) return "^7";
            if (c == Color.Gray) return "^8";
            if (c == Color.LightBlue) return "^9";

            // fallback
            return "^7";
        }

        private readonly (Color color, string code)[] InSimPalette =
        {
            (Color.Black,      "^0"),
            (Color.Red,        "^1"),
            (Color.LimeGreen,      "^2"),
            (Color.Yellow,     "^3"),
            (Color.Blue,       "^4"),
            (Color.Magenta,    "^5"),
            (Color.Cyan,       "^6"),
            (Color.White,      "^7"),
            (Color.Gray,       "^8"),
            (Color.LightBlue,  "^9"),
        };

        private void OpenInSimPalette(Button targetBtn, Action<string> setColor)
        {
            Form popup = new Form();
            popup.Text = "InSim Color Picker";
            popup.FormBorderStyle = FormBorderStyle.FixedToolWindow;
            popup.StartPosition = FormStartPosition.CenterParent;
            popup.Size = new Size(220, 220);

            int x = 10, y = 10;

            foreach (var item in InSimPalette)
            {
                Button b = new Button();
                b.Size = new Size(40, 40);
                b.Location = new Point(x, y);
                b.BackColor = item.color;
                b.FlatStyle = FlatStyle.Flat;

                b.Click += (s, e) =>
                {
                    targetBtn.BackColor = item.color;
                    setColor(item.code);
                    popup.Close();
                };

                popup.Controls.Add(b);

                x += 45;
                if (x > 180)
                {
                    x = 10;
                    y += 45;
                }
            }

            popup.ShowDialog();
        }
        private void PickColor(Button btn, Action<string> setInSimColor)
        {
            using (var dlg = new ColorDialog())
            {
                dlg.FullOpen = true;
                dlg.Color = btn.BackColor;

                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    Color selected = dlg.Color;

                    // ustaw UI kolor
                    btn.BackColor = selected;

                    // zamień na InSim code (^7 etc.)
                    string code = ToInSimColor(selected);
                    setInSimColor(code);
                }
            }
        }



        // ─────────────────────────────────────────────────────
        //  InSim callbacks
        // ─────────────────────────────────────────────────────
        private void OnCarData(object sender, CarDataEventArgs e)
        {

            byte viewPlid = _insim.ViewPLID;
            // Ustaw PLID gracza (pierwszy samochód)
            if (_playerPLID == 0)
                _playerPLID = e.Car.PLID;

            if (viewPlid != 0)
                _lastKnownPlayerPLID = viewPlid;
            else if (_lastKnownPlayerPLID == 0)
                return;  // jeszcze nie wiadomo, które auto jest nasze


            // Liczenie TYLKO dla gracza!
            if (e.Car.PLID != _lastKnownPlayerPLID)
                return;  // ← WYJDŹ jeśli to nie gracz

            _drift.Update(e.Car);  // ← Teraz bezpieczne!
            double speed = e.Car.SpeedKmh;

            // Konwersja Heading z LFS (0-65535) na stopnie (0-360)
            double headingDeg = (e.Car.Heading / 65535.0) * 360.0;
            _indicators.Update(headingDeg);

            this.BeginInvoke((Action)(() =>
            {
                _speedKmh   = speed;
                _driftAngle = _drift.DriftAngleDeg;
                _isDrifting = _drift.IsDrifting;
                _isSpeeding = _drift.IsSpeeding;

                _speedLabel.Text      = ((int)speed).ToString();
                _angleValueLabel.Text = ((int)_driftAngle).ToString() + "°";
                _angleValueLabel.ForeColor = _isDrifting
                    ? Color.FromArgb(255, 80, 80) : Color.FromArgb(60, 180, 255);

                _speedometer.Speed     = speed;
                _speedometer.DriftAngle = _driftAngle;
                _speedometer.IsDrifting = _isDrifting;
                _speedometer.Invalidate();
            }));
        }

        private void OnDriftScored(long runPts, int combo, string label, string labelindr, string labelindl)
        {
            this.BeginInvoke((Action)(() =>
            {
                _runPoints  = runPts;
                _totalScore = _drift.TotalScore;
                _combo      = combo;
                _driftLabel = label;
                _indicatorLabelR = labelindr;
                _indicatorLabelL = labelindl;

                UpdateScoreLabels();
                if (_showHudCheck.Checked && _insim.IsConnected && _insim.IsRaceNow)
                    UpdateInGameHUD();
            }));
        }

        private void OnDriftStarted()
        {
            this.BeginInvoke((Action)(() =>
            {
                _runPoints = 0;
                UpdateScoreLabels();
            }));
        }

        private void OnDriftEnded(long runPts)
        {
            this.BeginInvoke((Action)(() =>
            {
                _lastAward = _drift.LastAwardedText;
                UpdateScoreLabels();
                if (_showHudCheck.Checked && _insim.IsConnected)
                {
                    // Flash award text in game
                    ShowInGameAward(_lastAward);
                    _awardTick = 0;
                    _awardTimer.Start();
                }
            }));
        }

        private void OnStatus(object sender, StatusEventArgs e)
        {
            BeginInvoke((Action)(() =>
            {
                _statusLabel.Text      = e.Message;
                _statusLabel.ForeColor = e.IsError ? Color.FromArgb(220,80,80) : Color.FromArgb(100,200,120);
            }));
        }

        private void OnIndicatorStateChanged(IndicatorManager.IndicatorState newState)
        {
            this.BeginInvoke((Action)(() =>
            {
                // Aktualizuj UI
                _indicatorDisplayLabel.Text = _indicators.GetIndicatorText();

                // Zmień kolor w zależności od stanu
                _indicatorDisplayLabel.ForeColor = newState switch
                {
                    IndicatorManager.IndicatorState.Left => Color.FromArgb(100, 200, 255),
                    IndicatorManager.IndicatorState.Right => Color.FromArgb(100, 200, 255),
                    IndicatorManager.IndicatorState.Hazard => Color.FromArgb(255, 180, 0),
                    _ => Color.FromArgb(100, 100, 100)
                };

                // Wyślij klawisz (7/8/9/0) do LFS w oddzielnym wątku
                System.Threading.ThreadPool.QueueUserWorkItem(state =>
                {
                    try
                    {
                        System.Threading.Thread.Sleep(50);
                        _indicators.SendKeyToLFS();
                    }
                    catch { }
                });

                // Zaktualizuj label statusu
                _indicatorStatusLabel.Text = $"Current status:\n{newState}";
            }));
        }

        private void OnConnected(object sender, EventArgs e)
        {
            BeginInvoke((Action)(() =>
            {
                _connectBtn.Enabled    = false;
                _disconnectBtn.Enabled = true;
                _resetBtn.Enabled      = true;
                _revLimiter.Start();
                _connectionStateLabel.Text      = "⬤  Connected with LFS";
                _connectionStateLabel.ForeColor = Color.FromArgb(60,220,100);
                if (_showHudCheck.Checked)
                    InitInGameHUD();

            }));
            System.Threading.ThreadPool.QueueUserWorkItem(_ =>
            {
                _tireTemperatureLimiter.Connect();
            });
        }

        private void OnDisconnected(object sender, EventArgs e)
        {
            BeginInvoke((Action)(() =>
            {
                _connectBtn.Enabled    = true;
                _disconnectBtn.Enabled = false;
                _resetBtn.Enabled      = false;
                _revLimiter.Stop();
                _connectionStateLabel.Text      = "⬤  Rozłączono";
                _connectionStateLabel.ForeColor = Color.FromArgb(130,130,165);
                _speedKmh = 0; _driftAngle = 0;
                _speedLabel.Text = "0"; _angleValueLabel.Text = "0°";
                _speedometer.Speed = 0; _speedometer.Invalidate();
            }));

            _tireTemperatureLimiter.Disconnect();
        }

        // ─────────────────────────────────────────────────────
        //  Score labels
        // ─────────────────────────────────────────────────────
        private void UpdateScoreLabels()
        {
            _scoreValueLabel.Text = _drift.TotalScore.ToString("N0");
            _runValueLabel.Text   = _drift.IsDrifting
                ? _drift.CurrentRunPoints.ToString("N0") : "—";
            _runValueLabel.Text = _drift.IsSpeeding
                ? _drift.CurrentRunPoints.ToString("N0") : "—";
            _comboValueLabel.Text = $"x{_drift.ComboMultiplier}";
            _comboValueLabel.ForeColor = Color.FromArgb(255, 60, 60);
            /*
                ? Color.FromArgb(255,60,60)
                : _drift.ComboMultiplier >= 4
                    ? Color.FromArgb(255,160,40)
                    : _drift.ComboMultiplier >= 3
                    ? Color.FromArgb(255, 160, 40)
                    : Color.FromArgb(255, 255, 40);
            */
        }

        // ─────────────────────────────────────────────────────
        //  In-game HUD via IS_BTN
        //
        //  Layout (all in 0-200 coord space, recommended area L 0-110, T 30-170):
        //
        //   [BTN_SCORE ]  total score       — top centre, wide
        //   [BTN_RUN   ]  current run pts   — below score
        //   [BTN_COMBO ]  combo x N         — right of run
        //   [BTN_LABEL ]  "GREAT DRIFT" etc — below run, fades
        //   [BTN_AWARD ]  "EPIC! 5000 pts"  — flashes on drift end
        // ─────────────────────────────────────────────────────
        static byte xPos = 108;
        static byte xPosSec = 80;
        static byte xPosT = 120;
        private void InitInGameHUD()
        {
            // Static header button — "DRIFT BUDDY" title (always visible)
            _insim.ShowButton(BTN_SCORE, InSimColor1 + _drift.TotalScore.ToString("N0") + InSimColor1,
                l: 70, t:3, w:60, h:15, bStyle:2);
        }
        
        private void UpdateInGameHUD()
        {
            if (!_insim.IsConnected) return;

            // ── Total score (top, persistent) ────────────────
            

            // ── Current run ───────────────────────────────────
            if (_drift.IsDrifting || _drift.IsSpeeding)
            {

                string angleCol = _driftLabel.StartsWith("DOJEBANY") ? InSimColor3
                                : _driftLabel.StartsWith("DOSPERMIONY") ? InSimColor4
                                : _driftLabel.StartsWith("POJEBANA") ? InSimColor3
                                : _driftLabel.StartsWith("POKURWIONA") ? InSimColor4
                                : _driftLabel.StartsWith("DOBRY") ? InSimColor2
                                : _driftLabel.StartsWith("SZYBKA") ? InSimColor2
                                : InSimColor1;

                string scoreText = _drift.IsSpeeding
                 ? $"{angleCol}{_drift.TotalScore:N0}"
                : $"{angleCol}{_drift.TotalScore:N0}{angleCol}";

                scoreText = _drift.IsDrifting
                 ? $"{angleCol}{_drift.TotalScore:N0}"  
                : $"{angleCol}{_drift.TotalScore:N0}{angleCol}";


                _insim.ShowButton(BTN_SCORE, scoreText,
                    l: 70, t: 3, w: 60, h: 15, bStyle: 2);



                




                
                
                


                // ── Drift label ───────────────────────────────
                
                _insim.ShowButton(BTN_LABEL, angleCol + _driftLabel,
                    l: 90, t:15, w:20, h:7, bStyle:2);



                string spaceIND = _totalScore >= 10000 ? $" " : $"";
                spaceIND = _totalScore >= 100000 ? $"  " : $" ";
                spaceIND = _totalScore >= 1000000 ? $"   " : $"  ";
                string IND = $"{angleCol}{spaceIND}{_indicatorLabelR}";

                _insim.ShowButton(BTN_RIGHTIND, IND,
                l: 100, t: 3, w: 30, h: 15, bStyle: 2);

                IND = $"{angleCol}{_indicatorLabelL}{spaceIND}";

                _insim.ShowButton(BTN_LEFTIND, IND,
                l: 70, t: 3, w: 30, h: 15, bStyle: 2);

                // ── Combo ─────────────────────────────────────
                string comboCol = _drift.ComboMultiplier >= 5 ? InSimColor4
                                : _drift.ComboMultiplier >= 3 ? InSimColor3
                                : _drift.ComboMultiplier >= 2 ? InSimColor2 : InSimColor1;

                if (_drift.IsDrifting) 
                {
                    _insim.ShowButton(BTN_COMBO, $"{angleCol} {_angleValueLabel.Text} {comboCol}x{_drift.ComboMultiplier}",
                    l: xPosSec, t: 15, w: 10, h: 7, bStyle: 2);
                } else 
                {
                    _insim.ShowButton(BTN_COMBO, $"  {comboCol}x{_drift.ComboMultiplier}",
                        l: xPosSec, t: 15, w: 10, h: 7, bStyle: 2);
                }
                

                string runCol = _drift.CurrentRunPoints >= 5000 ? InSimColor4
                                : _drift.CurrentRunPoints >= 1500 ? InSimColor3 
                                : _drift.CurrentRunPoints >= 500 ? InSimColor2 : InSimColor1;

                string runText = $"{runCol}{_drift.CurrentRunPoints:N0}";
                _insim.ShowButton(BTN_RUN, runText,
                    l: xPos, t: 15, w: 10, h: 7, bStyle: 2);

            }
            else
            {
                // Clear run/combo/label when not drifting
                _insim.ShowButton(BTN_RUN,   "", l: xPos,  t:0, w:1, h:1, bStyle:2);
                _insim.ShowButton(BTN_COMBO, "", l: xPosSec, t:0, w:1, h:1, bStyle:2);
                _insim.ShowButton(BTN_LABEL, "", l: xPos,  t:0, w:1, h:1, bStyle:2);
            }
        }

        private void ShowInGameAward(string text)
        {
            if (!_insim.IsConnected) return;
            _insim.ShowButton(BTN_AWARD, "^2" + text,
                l: 80, t:22, w:40, h:5, bStyle:2);
        }

        // Flash award text — show 3 times then clear
        private void AwardTimer_Tick(object? sender, EventArgs e)
        {
            _awardTick++;
            if (_awardTick >= 20)
            {
                _awardTimer.Stop();
                if (_insim.IsConnected)
                    _insim.ShowButton(BTN_AWARD, "", l: xPosT, t:0, w:1, h:1, bStyle:2);
                    _insim.ShowButton(BTN_RUN, "", l: xPos, t: 0, w: 1, h: 1, bStyle: 2);
                    _insim.ShowButton(BTN_COMBO, "", l: xPosSec, t: 0, w: 1, h: 1, bStyle: 2);
                    _insim.ShowButton(BTN_LABEL, "", l: xPos, t: 0, w: 1, h: 1, bStyle: 2);

                string scoreText = _drift.IsSpeeding
                 ? $"{InSimColor2}{_drift.TotalScore:N0}"
                : $"{InSimColor1}{_drift.TotalScore:N0}{InSimColor1}";
                
                scoreText = _drift.IsDrifting
                 ? $"{InSimColor2}{_drift.TotalScore:N0}"
                : $"{InSimColor1}{_drift.TotalScore:N0}{InSimColor1}";
                _insim.ShowButton(BTN_SCORE, scoreText,
                    l: 70, t: 3, w: 60, h: 15, bStyle: 2);

                string IND = _drift.IsDrifting
                    ? $"{InSimColor2}{_indicatorLabelR}"
                    : $"";


                _insim.ShowButton(BTN_RIGHTIND, IND,
                l: 100, t: 3, w: 30, h: 15, bStyle: 2);

                IND = _drift.IsDrifting
                    ? $"{InSimColor2}{_indicatorLabelL}"
                    : $"";

                _insim.ShowButton(BTN_LEFTIND, IND,
                l: 70, t: 3, w: 30, h: 15, bStyle: 2);

            }
        }

        // ─────────────────────────────────────────────────────
        //  Helper builders
        // ─────────────────────────────────────────────────────

        
        private Panel MakePanel(int x, int y, int w, int h, Color bg, Control? parent = null)
        {
            var p = new Panel { Location = new Point(x, y), Size = new Size(w, h), BackColor = bg };
            (parent ?? (Control)this).Controls.Add(p);
            return p;
        }

        private Label MakeLabel(Control parent, string text, int x, int y, int w, int h,
            Color fore, Font? font = null, ContentAlignment align = ContentAlignment.MiddleLeft)
        {
            var l = new Label
            {
                Text = text, Location = new Point(x, y), Size = new Size(w, h),
                ForeColor = fore, BackColor = Color.Transparent,
                Font = font ?? this.Font, TextAlign = align
            };
            parent.Controls.Add(l);
            return l;
        }

        private TextBox MakeTextBox(Control parent, string text, int x, int y, int w, int h)
        {
            var tb = new TextBox
            {
                Text = text, Location = new Point(x, y), Size = new Size(w, h),
                ForeColor = Color.White, BackColor = Color.FromArgb(32, 32, 50),
                BorderStyle = BorderStyle.FixedSingle
            };
            parent.Controls.Add(tb);
            return tb;
        }

        private Button MakeButton(Control parent, string text, int x, int y, int w, int h, Color bg)
        {
            var btn = new Button
            {
                Text = text, Location = new Point(x, y), Size = new Size(w, h),
                FlatStyle = FlatStyle.Flat, BackColor = bg,
                ForeColor = Color.White, Font = new Font("Segoe UI", 8.5f, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            btn.FlatAppearance.BorderSize = 0;
            btn.FlatAppearance.MouseOverBackColor = ControlPaint.Light(bg, 0.25f);
            parent.Controls.Add(btn);
            return btn;
        }

        private PaintEventHandler BorderPaint(Color c) => (s, e) =>
        {
            using var p = new Pen(c, 1);
            e.Graphics.DrawRectangle(p, 0, 0, ((Control)s!).Width - 1, ((Control)s!).Height - 1);
        };

        private void UpdateTireLimiterUI(bool isPatched)
        {
            if (_tireStatusLabel != null)
            {
                _tireStatusLabel.Text = isPatched
                    ? "✅ ACTIVE - Patched"
                    : "❌ Not Patched";

                _tireStatusLabel.ForeColor = isPatched
                    ? Color.FromArgb(80, 255, 100)
                    : Color.FromArgb(255, 100, 100);
            }

            if (_tirePatchBtn != null)
            {
                if (isPatched)
                {
                    _tirePatchBtn.Text = "REMOVE PATCH";
                    _tirePatchBtn.BackColor = Color.FromArgb(60, 150, 60);
                }
                else
                {
                    _tirePatchBtn.Text = "APPLY PATCH";
                    _tirePatchBtn.BackColor = Color.FromArgb(180, 60, 60);
                }
            }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (_insim.IsConnected) { _insim.DeleteAllButtons(); System.Threading.Thread.Sleep(120); }
            try
            {
                _tireTemperatureLimiter.Disconnect();
            }
            catch { /* ignore */ }
            _insim.Dispose();
            _revLimiter.Dispose();
            base.OnFormClosing(e);
        }

        private void InitializeComponent() { }
    }

    // =========================================================
    //  Analog Speedometer + Drift Angle indicator
    // =========================================================
    public class SpeedometerControl : Control
    {
        public double Speed      { get; set; } = 0;
        public double DriftAngle { get; set; } = 0;
        public bool   IsDrifting { get; set; } = false;
        public bool   IsSpeeding { get; set; } = false;

        private const double MaxSpeed = 300.0;

        protected override void OnPaint(PaintEventArgs e)
        {
            var g = e.Graphics;
            g.SmoothingMode     = SmoothingMode.AntiAlias;
            g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias;

            int cx     = Width / 2;
            int cy     = Height - 16;
            int radius = Math.Min(Width / 2, Height) - 18;

            // Background arc fill
            using var bgBrush = new SolidBrush(Color.FromArgb(22, 22, 34));
            g.FillPie(bgBrush, cx - radius, cy - radius, radius * 2, radius * 2, 180, 180);

            // Outer ring
            using var outerPen = new Pen(Color.FromArgb(45, 45, 65), 2);
            g.DrawArc(outerPen, cx - radius, cy - radius, radius * 2, radius * 2, 180, 180);

            // Speed arc (red if drifting, else normal red)
            double fraction = Math.Min(Speed / MaxSpeed, 1.0);
            float sweep     = (float)(fraction * 180.0);
            if (sweep > 0.5f)
            {
                Color arcColor = IsDrifting ? Color.FromArgb(255, 60, 60) : Color.FromArgb(180, 30, 30);
                using var arcPen = new Pen(arcColor, 7);
                g.DrawArc(arcPen,
                    cx - radius + 10, cy - radius + 10,
                    (radius - 10) * 2, (radius - 10) * 2,
                    180, sweep);
            }

            // Drift angle arc (blue, inner ring)
            if (DriftAngle > 1.0)
            {
                double maxAngle = 75.0;
                float driftSweep = (float)(Math.Min(DriftAngle / maxAngle, 1.0) * 180.0);
                Color dc = IsDrifting ? Color.FromArgb(60, 200, 255) : Color.FromArgb(40, 80, 120);
                using var driftPen = new Pen(dc, 4);
                g.DrawArc(driftPen,
                    cx - radius + 22, cy - radius + 22,
                    (radius - 22) * 2, (radius - 22) * 2,
                    180, driftSweep);
            }

            // Tick marks
            for (int i = 0; i <= 12; i++)
            {
                double angle = Math.PI + (i / 12.0) * Math.PI;
                bool major = (i % 2 == 0);
                int tickOuter = radius - 3;
                int tickInner = major ? radius - 18 : radius - 11;

                int x1 = (int)(cx + Math.Cos(angle) * tickOuter);
                int y1 = (int)(cy + Math.Sin(angle) * tickOuter);
                int x2 = (int)(cx + Math.Cos(angle) * tickInner);
                int y2 = (int)(cy + Math.Sin(angle) * tickInner);

                using var tickPen = new Pen(
                    major ? Color.FromArgb(160, 160, 190) : Color.FromArgb(60, 60, 80),
                    major ? 2f : 1f);
                g.DrawLine(tickPen, x1, y1, x2, y2);

                if (major)
                {
                    int spd = (int)(i / 12.0 * MaxSpeed);
                    int lx  = (int)(cx + Math.Cos(angle) * (tickInner - 14)) - 14;
                    int ly  = (int)(cy + Math.Sin(angle) * (tickInner - 14)) - 7;
                    using var tf = new Font("Segoe UI", 7f);
                    g.DrawString(spd.ToString(), tf, Brushes.Gray, lx, ly);
                }
            }

            // Needle
            double needleAngle = Math.PI + fraction * Math.PI;
            int    needleLen   = radius - 24;
            int    nx = (int)(cx + Math.Cos(needleAngle) * needleLen);
            int    ny = (int)(cy + Math.Sin(needleAngle) * needleLen);
            using var needlePen = new Pen(IsDrifting ? Color.FromArgb(255,80,80) : Color.FromArgb(220,40,40), 3f)
            {
                StartCap = LineCap.Round,
                EndCap   = LineCap.ArrowAnchor
            };
            g.DrawLine(needlePen, cx, cy, nx, ny);

            // Center hub
            using var hubBrush = new SolidBrush(Color.FromArgb(220, 40, 40));
            g.FillEllipse(hubBrush, cx - 7, cy - 7, 14, 14);
            using var hubRing = new Pen(Color.FromArgb(50, 50, 70), 2);
            g.DrawEllipse(hubRing, cx - 7, cy - 7, 14, 14);

            // Drift angle label inside arc
            if (DriftAngle > 5)
            {
                using var af = new Font("Segoe UI", 8.5f, FontStyle.Bold);
                string atext = $"{(int)DriftAngle}°";
                Color ac = IsDrifting ? Color.FromArgb(80, 210, 255) : Color.FromArgb(80, 120, 180);
                var sz = g.MeasureString(atext, af);
                g.DrawString(atext, af, new SolidBrush(ac), cx - sz.Width / 2, cy - radius / 2 - sz.Height / 2);
            }
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            e.Graphics.Clear(Color.FromArgb(13, 13, 20));
        }
    }
}
