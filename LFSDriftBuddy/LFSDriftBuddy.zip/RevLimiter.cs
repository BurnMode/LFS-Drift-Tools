using System;
using System.Net;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LFSDriftBuddy
{
    // =========================================================
    //  RevLimiter — OutGauge UDP reader + ignition cut via WinAPI
    //
    //  Wymaga w LFS cfg.txt:
    //    OutGauge Mode 2
    //    OutGauge Delay 1
    //    OutGauge IP 127.0.0.1
    //    OutGauge Port 35555
    //    OutGauge ID 1
    // =========================================================

    public class OutGaugeData
    {
        public float RPM      { get; set; }
        public float Speed    { get; set; }   // m/s
        public float Throttle { get; set; }   // 0..1
        public float Gear     { get; set; }
        public float EngTemp  { get; set; }
        public float Fuel     { get; set; }
        public bool  Valid    { get; set; }
    }

    public class RevLimiter : IDisposable
    {
        // ── WinAPI ────────────────────────────────────────────
        [DllImport("user32.dll", SetLastError = true)]
        private static extern IntPtr FindWindow(string? lpClassName, string lpWindowName);

        [DllImport("user32.dll", SetLastError = true)]
        private static extern bool PostMessage(IntPtr hWnd, uint Msg, IntPtr wParam, IntPtr lParam);

        private const uint WM_KEYDOWN = 0x0100;
        private const uint WM_KEYUP   = 0x0101;
        private const int  VK_I       = 0x49;  // klawisz "I" – zapłon w LFS

        // ── Settings (publiczne, można zmieniać z UI) ─────────
        public int   RpmLimit    { get; set; } = 7500;   // RPM przy którym tnie
        public int   CutMs       { get; set; } = 80;     // czas wyłączenia zapłonu [ms]
        public int   CooldownMs  { get; set; } = 25;     // minimalny czas między cięciami
        public bool  Enabled     { get; set; } = true;
        public int   UdpPort     { get; set; } = 35555;
        
        // ── State ─────────────────────────────────────────────
        public OutGaugeData LastData   { get; private set; } = new OutGaugeData();
        public bool          IsCutting { get; private set; } = false;


        public float           lastRPM { get; private set; } = 0;

        private bool        _ignitionState = true;  // zakładamy że silnik jest włączony na start
        public bool         IgnitionOn => _ignitionState;
        public bool          IsRunning { get; private set; } = false;
        public int           CutCount  { get; private set; } = 0;   // ile razy uciął

        // ── Events ────────────────────────────────────────────
        public event Action<OutGaugeData>? DataReceived;   // każdy pakiet UDP
        public event Action?               CutStarted;     // zapłon wyłączony
        public event Action?               CutEnded;       // zapłon przywrócony
        public event Action<string>?       Error;

        // ── Internals ─────────────────────────────────────────
        private UdpClient?        _udp;
        private CancellationTokenSource _cts = new();
        private DateTime          _lastCut   = DateTime.MinValue;
        private readonly object   _lock      = new();

        // ─────────────────────────────────────────────────────
        //  Start / Stop
        // ─────────────────────────────────────────────────────
        public void Start()
        {
            if (IsRunning) return;
            try
            {
                _cts = new CancellationTokenSource();
                _udp = new UdpClient(UdpPort);
                _udp.Client.ReceiveTimeout = 2000;
                IsRunning = true;
                Task.Run(() => ReceiveLoop(_cts.Token));
            }
            catch (Exception ex)
            {
                Error?.Invoke($"Nie można otworzyć UDP {UdpPort}: {ex.Message}");
                IsRunning = false;
            }
        }

        public void Stop()
        {
            if (!IsRunning) return;
            _cts.Cancel();
            _udp?.Close();
            _udp = null;
            IsRunning  = false;
            IsCutting  = false;
            LastData   = new OutGaugeData();
        }

        // ─────────────────────────────────────────────────────
        //  UDP receive loop
        // ─────────────────────────────────────────────────────
        private void ReceiveLoop(CancellationToken ct)
        {
            var ep = new IPEndPoint(IPAddress.Any, 0);
            while (!ct.IsCancellationRequested)
            {
                try
                {
                    byte[] data = _udp!.Receive(ref ep);
                    if (data.Length < 64) continue;

                    var og = ParseOutGauge(data);
                    LastData = og;
                    DataReceived?.Invoke(og);

                    if (Enabled && og.Valid && !IsCutting)
                        CheckRpm(og.RPM, og.Throttle);
                }
                catch (SocketException)
                {
                    if (!ct.IsCancellationRequested)
                        continue;   // timeout – normalny stan gdy LFS nie wysyła
                }
                catch (Exception ex)
                {
                    if (!ct.IsCancellationRequested)
                        Error?.Invoke("OutGauge error: " + ex.Message);
                }
            }
        }

        // ─────────────────────────────────────────────────────
        //  RPM check & cut trigger
        // ─────────────────────────────────────────────────────
        private void CheckRpm(float rpm, float throttle)
        {
            if (rpm < RpmLimit - 15) return;
            if (throttle < 0.20f) return;   // tylko przy wciśniętym gazie
            if (rpm < 50f)
            {
                _ignitionState = false;
                return;
            }
            if (rpm > 300f && !IsCutting)
                _ignitionState = true;


            
            


                lock (_lock)
            {
                if (IsCutting) return;
                double gap = (DateTime.UtcNow - _lastCut).TotalMilliseconds;
                if (gap < CooldownMs) return;

                IsCutting = true;
                CutCount++;
            }

            // Uruchom asynchronicznie żeby nie blokować pętli UDP

           
                Task.Run(() => DoCut(rpm));
            
                
            


        }

        private async Task DoCut(float rpm)
        {
            CutStarted?.Invoke();


            /*
            if (_ignitionState && rpm >= RpmLimit - 20)

            {                              
                PressIgnitionKey();               // zapłon OFF
               
              
 
            }
                  

            if (!_ignitionState && rpm < RpmLimit + 200)

            {
                await Task.Delay(CutMs);
                PressIgnitionKey();              // zapłon ON
                _lastCut = DateTime.UtcNow;
                lock (_lock) { IsCutting = false; }
                CutEnded?.Invoke();

            }
            else if (!_ignitionState && rpm < RpmLimit + 400)

            {
                await Task.Delay(CutMs * 2);
                PressIgnitionKey();              // zapłon ON
                _lastCut = DateTime.UtcNow;
                lock (_lock) { IsCutting = false; }
                CutEnded?.Invoke();

            }
            else if (!_ignitionState && rpm < RpmLimit + 600)

            {
                await Task.Delay(CutMs * 3);
                PressIgnitionKey();              // zapłon ON
                _lastCut = DateTime.UtcNow;
                lock (_lock) { IsCutting = false; }
                CutEnded?.Invoke();

            }
            else if(!_ignitionState)
            {
                await Task.Delay(CutMs * 2);
                
                    PressIgnitionKey();
                _lastCut = DateTime.UtcNow;
                lock (_lock) { IsCutting = false; }
                CutEnded?.Invoke();
            }
            */

            PressIgnitionKey();
            await Task.Delay(CutMs);
            PressIgnitionKey();              // zapłon ON
            _lastCut = DateTime.UtcNow;
            lock (_lock) { IsCutting = false; }
            CutEnded?.Invoke();





        }

        // ─────────────────────────────────────────────────────
        //  Wysyłanie klawisza "I" do okna LFS
        // ─────────────────────────────────────────────────────
        private void PressIgnitionKey()
        {
            // Szukamy okna – LFS może mieć różne tytuły, próbuj kilka wariantów
            IntPtr hwnd = FindLfsWindow();
            if (hwnd == IntPtr.Zero)
            {
                Error?.Invoke("Nie znaleziono okna LFS (rev limiter)");
                return;
            }

            // PostMessage jest nieblokujące i działa nawet gdy LFS jest w tle
            PostMessage(hwnd, WM_KEYDOWN, (IntPtr)VK_I, (IntPtr)0x00170001);
            Thread.Sleep(20);
            PostMessage(hwnd, WM_KEYUP,   (IntPtr)VK_I, (IntPtr)0xC0170001);
            _ignitionState = !_ignitionState;  // odwróć stan po każdym naciśnięciu
        }

        private static IntPtr FindLfsWindow()
        {
            // LFS używa różnych tytułów zależnie od wersji i trybu
            string[] titles = { "LFS", "Live for Speed", "LFS S3", "LFS S2", "LFS Demo" };
            foreach (var t in titles)
            {
                IntPtr h = FindWindow(null, t);
                if (h != IntPtr.Zero) return h;
            }
            return IntPtr.Zero;
        }

        // ─────────────────────────────────────────────────────
        //  OutGauge packet parser
        //
        //  Struktura (96 bajtów, little-endian):
        //  Offset  0 : uint   Time
        //  Offset  4 : char[4] Car
        //  Offset  8 : ushort Flags
        //  Offset 10 : byte   Gear
        //  Offset 11 : byte   PLID
        //  Offset 12 : float  Speed  (m/s)
        //  Offset 16 : float  RPM
        //  Offset 20 : float  Turbo
        //  Offset 24 : float  EngTemp
        //  Offset 28 : float  Fuel
        //  Offset 32 : float  OilPress
        //  Offset 36 : float  OilTemp
        //  Offset 40 : uint   DashLights
        //  Offset 44 : uint   ShowLights
        //  Offset 48 : float  Throttle
        //  Offset 52 : float  Brake
        //  Offset 56 : float  Clutch
        //  Offset 60 : char[16] Display1
        //  Offset 76 : char[16] Display2
        //  Offset 92 : int    ID  (opcjonalne)
        // ─────────────────────────────────────────────────────
        private static OutGaugeData ParseOutGauge(byte[] d)
        {
            return new OutGaugeData
            {
                RPM      = BitConverter.ToSingle(d, 16),
                Speed    = BitConverter.ToSingle(d, 12),
                Throttle = d.Length >= 52 ? BitConverter.ToSingle(d, 48) : 0f,
                Gear     = d[10],
                EngTemp  = d.Length >= 28 ? BitConverter.ToSingle(d, 24) : 0f,
                Fuel     = d.Length >= 32 ? BitConverter.ToSingle(d, 28) : 0f,
                Valid    = true,
            };
        }

        public void Dispose() => Stop();
    }
}
