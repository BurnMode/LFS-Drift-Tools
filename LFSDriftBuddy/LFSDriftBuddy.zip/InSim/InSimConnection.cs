using System;
using System.Net.Sockets;
using System.Threading;
using System.Text;

namespace LFSDriftBuddy.InSim
{
    public class CarDataEventArgs : EventArgs
    {
        public CompCar Car { get; set; }
    }

    public class StatusEventArgs : EventArgs
    {
        public string Message { get; set; }
        public bool IsError { get; set; }
    }

    /// <summary>
    /// Manages the TCP connection to LFS InSim, sends/receives packets.
    /// </summary>
    public class InSimConnection : IDisposable
    {
        // ── Public events ─────────────────────────────────────
        public event EventHandler<CarDataEventArgs>  CarDataReceived;
        public event EventHandler<StatusEventArgs>   StatusChanged;
        public event EventHandler                    Connected;
        public event EventHandler                    Disconnected;

        // ── State ─────────────────────────────────────────────
        private TcpClient   _client;
        private NetworkStream _stream;
        private Thread      _receiveThread;
        private byte[]      _buffer     = new byte[8192];
        private int         _bufferLen  = 0;
        private volatile bool _running  = false;
        private StateFlags _gameState = 0;
        public StateFlags GameState => _gameState;
        public byte ViewPLID { get; private set; } = 0;

        public bool IsConnected => _client?.Connected == true && _running;

        // ─────────────────────────────────────────────────────
        //  Connect
        // ─────────────────────────────────────────────────────
        public void Connect(string host, int port, string adminPassword = "", ushort mciInterval = 200)
        {
            try
            {
                Disconnect();

                _client = new TcpClient();
                _client.Connect(host, port);
                _stream = _client.GetStream();

                _running = true;

                // Start receive thread
                _receiveThread = new Thread(ReceiveLoop)
                {
                    IsBackground = true,
                    Name = "InSim-Receive"
                };
                _receiveThread.Start();

                // Send IS_ISI – request MCI packets every mciInterval ms
                var isi = Packets.BuildISI(
                    udpPort:  0,
                    flags:    ISFlags.ISF_MCI,
                    prefix:   33,               // '!'
                    interval: mciInterval,
                    admin:    adminPassword,
                    iname:    "DriftBuddy"
                );
                Send(isi);
                Send(Packets.BuildTiny(4, TinyType.TINY_SST));
                RaiseStatus("Połączono z LFS na " + host + ":" + port);
                Connected?.Invoke(this, EventArgs.Empty);
                Send(Packets.BuildTiny(4, TinyType.TINY_SST));
            }
            catch (Exception ex)
            {
                RaiseStatus("Błąd połączenia: " + ex.Message, isError: true);
                Cleanup();
            }
        }

        // ─────────────────────────────────────────────────────
        //  Disconnect
        // ─────────────────────────────────────────────────────
        public void Disconnect()
        {
            if (_running)
            {
                _running = false;
                Cleanup();
                Disconnected?.Invoke(this, EventArgs.Empty);
                RaiseStatus("Rozłączono.");
            }
        }

        // ─────────────────────────────────────────────────────
        //  Send raw bytes
        // ─────────────────────────────────────────────────────
        public void Send(byte[] data)
        {
            try
            {
                _stream?.Write(data, 0, data.Length);
            }
            catch (Exception ex)
            {
                RaiseStatus("Błąd wysyłania: " + ex.Message, isError: true);
            }
        }

        // ─────────────────────────────────────────────────────
        //  Show a button inside LFS
        // ─────────────────────────────────────────────────────
        // Show a button inside LFS
        // Coordinates are 0-200 (not percentages).
        // Recommended area: L 0-110, T 30-170
        // ISB_DARK = 32, ISB_LIGHT = 16
        public void ShowButton(byte clickId, string text,
                               byte l = 35, byte t = 32, byte w = 40, byte h = 8,
                               byte bStyle = 32 /* ISB_DARK */ )
        {
            var btn = Packets.BuildBTN(
                ucid:    0,
                clickId: clickId,
                inst:    0,
                bStyle:  bStyle,
                typeIn:  0,
                l: l, t: t, w: w, h: h,
                text:    text,
                reqI:    1          // non-zero is required!
            );
            Send(btn);
        }

        public bool IsRaceNow =>
        (_gameState & StateFlags.ISS_GAME) == 0;
        //(_gameState & StateFlags.ISS_REPLAY) == 2 ||
       // (_gameState & StateFlags.ISS_FRONT_END) == 0 ||
        //(_gameState & StateFlags.ISS_PAUSED) == 0;

        public event EventHandler<bool>? RaceStateChanged; // true = wszedł do wyścigu

        /// <summary>Delete all InSim buttons for local connection (UCID=0).</summary>
        public void DeleteAllButtons()
        {
            Send(Packets.BuildBFN_DeleteAll(0));
        }

        // ─────────────────────────────────────────────────────
        //  Receive loop
        // ─────────────────────────────────────────────────────
        private void ReceiveLoop()
        {
            byte[] tmp = new byte[4096];

            try
            {
                while (_running)
                {
                    int read = _stream.Read(tmp, 0, tmp.Length);
                    if (read == 0) break;  // connection closed

                    // Append to buffer
                    if (_bufferLen + read > _buffer.Length)
                    {
                        // Grow buffer
                        byte[] newBuf = new byte[_buffer.Length * 2];
                        Array.Copy(_buffer, newBuf, _bufferLen);
                        _buffer = newBuf;
                    }
                    Array.Copy(tmp, 0, _buffer, _bufferLen, read);
                    _bufferLen += read;

                    // Process complete packets
                    ProcessBuffer();
                }
            }
            catch (Exception ex)
            {
                if (_running)
                    RaiseStatus("Błąd odbioru: " + ex.Message, isError: true);
            }
            finally
            {
                _running = false;
                Cleanup();
                Disconnected?.Invoke(this, EventArgs.Empty);
            }
        }

        private void ProcessBuffer()
        {
            while (_bufferLen >= 4)
            {
                // CRITICAL: LFS Size byte = actual_bytes / 4
                // So actual packet size = Size * 4
                int packetSize = _buffer[0] * 4;
                if (packetSize < 4) packetSize = 4;   // minimum safety

                if (_bufferLen < packetSize) break;    // Incomplete packet yet

                // Copy complete packet
                byte[] packet = new byte[packetSize];
                Array.Copy(_buffer, packet, packetSize);

                // Shift buffer
                int remaining = _bufferLen - packetSize;
                Array.Copy(_buffer, packetSize, _buffer, 0, remaining);
                _bufferLen = remaining;

                // Dispatch
                HandlePacket(packet);
            }
        }

        private void HandlePacket(byte[] packet)
        {
            if (packet.Length < 4) return;

            PacketType type = (PacketType)packet[1];

            switch (type)
            {
                // ── Keep-alive ────────────────────────────────
                case PacketType.ISP_TINY:
                    if (packet.Length >= 4 && packet[3] == (byte)TinyType.TINY_NONE)
                        Send(packet);  // Echo back
                    break;

                // ── Multi Car Info ────────────────────────────
                case PacketType.ISP_MCI:
                    HandleMCI(packet);
                    break;

                // ── Version reply ─────────────────────────────
                case PacketType.ISP_VER:
                    HandleVer(packet);
                    break;

                case PacketType.ISP_STA:
                    HandleSTA(packet);
                    break;
            }
        }

        private void HandleSTA(byte[] p)
        {
            // IS_STA: Size=28(=7*4), Type=5
            // Flags są na offsetcie 14 (word LE)
            // Układ: Size,Type,ReqI,Zero, Speed(word), Heading(word),
            //        Gear,PLID,InGameCam,ViewPLID, ShowOBJ(word),NumP,NumConns,
            //        NumFinished,RaceInProg, QualMins,RaceLaps,Sp2,Sp3,
            //        Track[6],Weather,Wind
            // -> Flags są na byte 6..7 (word)
            if (p.Length < 12) return;

            var prev = _gameState;
            _gameState = (StateFlags)BitConverter.ToUInt16(p, 6);
            ViewPLID = p[11];
            bool nowRace = IsRaceNow;
            bool wasRace = (prev & StateFlags.ISS_GAME) != 0;
                           //(prev & StateFlags.ISS_REPLAY) == 0 ||
                           //(prev & StateFlags.ISS_GAME) != 0 &&
                           //(prev & StateFlags.ISS_FRONT_END) == 0 ||
                           //(prev & StateFlags.ISS_GAME) != 0 &&
                           //(prev & StateFlags.ISS_PAUSED) == 0;

            if (nowRace != wasRace)
                RaceStateChanged?.Invoke(this, nowRace);
        }
        private void HandleMCI(byte[] packet)
        {
            if (packet.Length < 4) return;

            try
            {
                var mci = IS_MCI_Packet.Parse(packet);
                if (mci.Cars != null)
                {
                    foreach (var car in mci.Cars)
                    {
                        CarDataReceived?.Invoke(this, new CarDataEventArgs { Car = car });
                    }
                }
            }
            catch { /* Malformed packet – ignore */ }
        }

        private void HandleVer(byte[] packet)
        {
            // IS_VER: Size=20, Type=2, ReqI, Zero, Version[8], Product[6], InSimVer(word)
            if (packet.Length >= 20)
            {
                string version = Encoding.Latin1.GetString(packet, 4, 8).TrimEnd('\0');
                string product = Encoding.Latin1.GetString(packet, 12, 6).TrimEnd('\0');
                ushort isVer   = BitConverter.ToUInt16(packet, 18);
                RaiseStatus($"LFS {version} ({product}), InSim v{isVer}");
            }
        }

        // ─────────────────────────────────────────────────────
        private void Cleanup()
        {
            try { _stream?.Close(); } catch { }
            try { _client?.Close(); } catch { }
            _stream = null;
            _client = null;
        }

        private void RaiseStatus(string message, bool isError = false)
        {
            StatusChanged?.Invoke(this, new StatusEventArgs { Message = message, IsError = isError });
        }

        public void Dispose() => Disconnect();
    }
}
